package motorbike_reservation_system.admin_CRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminCrudApplication.class, args);
	}

}
