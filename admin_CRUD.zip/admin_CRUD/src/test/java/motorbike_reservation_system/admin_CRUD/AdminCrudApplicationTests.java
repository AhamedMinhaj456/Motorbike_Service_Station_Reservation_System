package motorbike_reservation_system.admin_CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
